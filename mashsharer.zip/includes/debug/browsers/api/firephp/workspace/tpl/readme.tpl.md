FirePHPCore Server Library
==========================

Status: stable

Version: [%%VERSION%%](https://github.com/firephp/firephp-core/tree/v%%VERSION%%)

This archive contains the *FirePHPCore* PHP server library.

Links
-----

  * Documentation: http://docs.sourcemint.org/firephp.org/firephp/1/-docs/
  * Install: http://docs.sourcemint.org/firephp.org/firephp/1/-docs/Configuration/Traditional
  * Support: http://docs.sourcemint.org/firephp.org/firephp/1/-docs/OpenSource#support
  * Author: [Christoph Dorn](http://www.christophdorn.com/)
  * License: [MIT License](http://www.opensource.org/licenses/mit-license.php)
