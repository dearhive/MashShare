<?php
?>
<script id="tmpl-mashsb-rwmb-upload-area" type="text/html">
  <div class="mashsb-rwmb-upload-inside">
    <h3>{{{ i18nRwmbMedia.uploadInstructions }}}</h3>
    <p> or</p>
    <p><a href="#" class="mashsb-rwmb-browse-button button button-hero" id="{{{ _.uniqueId( 'mashsb-rwmb-upload-browser-') }}}">{{{ i18nRwmbMedia.select }}}</a></p>
  </div>
</script>
