
## Deploy MashShare new version

- Update package.json version number
- Update readme.txt changelog number
- Update Upgrade Notice in readme.txt
- Run `grunt build` to build the dist version in ./dist/releases/mashshare/trunk